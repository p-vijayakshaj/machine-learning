import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder


# ---------------------------------------------------
# LOAD DATASET
# ---------------------------------------------------

def load_dataset():
    df = pd.read_csv("merged_dataset.csv")

    # Features: numeric columns except State
    X = df.select_dtypes(include=[np.number])

    # Target: State
    y = df['State']

    # drop rows where State is NaN
    combined = pd.concat([X, y], axis=1)
    combined = combined[combined['State'].notna()]

    # fill NaN in numeric columns with mean
    X = combined.select_dtypes(include=[np.number])
    for col in X.columns:
        X[col] = X[col].fillna(X[col].mean())

    y = combined['State']

    return X, y


# ---------------------------------------------------
# EQUAL WIDTH BINNING
# ---------------------------------------------------

def equal_width_binning(series, bins=4):
    min_val = series.min()
    max_val = series.max()

    width = (max_val - min_val) / bins

    bin_labels = []

    for value in series:
        if pd.isna(value):
            bin_labels.append(-1)  # Assign -1 for NaN values
        else:
            index = int((value - min_val) / width)

            if index == bins:
                index = bins - 1

            bin_labels.append(index)

    return np.array(bin_labels)


# ---------------------------------------------------
# ENTROPY CALCULATION
# ---------------------------------------------------

def calculate_entropy(y):

    values, counts = np.unique(y, return_counts=True)
    probabilities = counts / len(y)

    entropy = 0

    for p in probabilities:
        entropy -= p * np.log2(p)

    return entropy


# ---------------------------------------------------
# GINI INDEX
# ---------------------------------------------------

def calculate_gini(y):

    values, counts = np.unique(y, return_counts=True)
    probabilities = counts / len(y)

    gini = 1

    for p in probabilities:
        gini -= p ** 2

    return gini


# ---------------------------------------------------
# INFORMATION GAIN
# ---------------------------------------------------

def information_gain(X_column, y):

    parent_entropy = calculate_entropy(y)

    values = np.unique(X_column)

    weighted_entropy = 0

    for val in values:

        subset = y[X_column == val]

        weight = len(subset) / len(y)

        weighted_entropy += weight * calculate_entropy(subset)

    IG = parent_entropy - weighted_entropy

    return IG


# ---------------------------------------------------
# ROOT NODE SELECTION
# ---------------------------------------------------

def find_root_feature(X, y):

    gains = {}

    for column in X.columns:

        IG = information_gain(X[column].values, y)

        gains[column] = IG

    best_feature = max(gains, key=gains.get)

    return best_feature, gains


# ---------------------------------------------------
# MAIN PROGRAM
# ---------------------------------------------------

if __name__ == "__main__":

    X, y = load_dataset()

    le = LabelEncoder()
    y_encoded = le.fit_transform(y)

    # Convert numeric features to categorical bins
    X_binned = X.copy()

    for column in X.columns:
        X_binned[column] = equal_width_binning(X[column], bins=4)

    # -----------------------------
    # A1 Entropy
    # -----------------------------
    entropy_value = calculate_entropy(y)

    print("Entropy of dataset:", entropy_value)

    # -----------------------------
    # A2 Gini
    # -----------------------------
    gini_value = calculate_gini(y)

    print("Gini Index:", gini_value)

    # -----------------------------
    # A3 Root Feature
    # -----------------------------
    root_feature, gains = find_root_feature(X_binned, y)

    print("Information Gain of features:", gains)
    print("Root Feature:", root_feature)

    # -----------------------------
    # A5 Decision Tree Model
    # -----------------------------
    X_train, X_test, y_train, y_test = train_test_split(
        X_binned, y, test_size=0.3, random_state=42
    )

    dt_model = DecisionTreeClassifier(criterion="entropy")

    dt_model.fit(X_train, y_train)

    print("Decision Tree Accuracy:", dt_model.score(X_test, y_test))

    # -----------------------------
    # A6 Tree Visualization
    # -----------------------------
    plt.figure(figsize=(12,8))

    plot_tree(
        dt_model,
        feature_names=X.columns,
        filled=True
    )

    plt.show()

    # -----------------------------
    # A7 Decision Boundary (2 features)
    # -----------------------------
    X_two = X_binned.iloc[:, :2]

    X_train2, X_test2, y_train2, y_test2 = train_test_split(
        X_two, y, test_size=0.3, random_state=42
    )

    dt2 = DecisionTreeClassifier()

    dt2.fit(X_train2, y_train2)

    x_min, x_max = X_two.iloc[:,0].min(), X_two.iloc[:,0].max()
    y_min, y_max = X_two.iloc[:,1].min(), X_two.iloc[:,1].max()

    xx, yy = np.meshgrid(
        np.linspace(x_min, x_max, 200),
        np.linspace(y_min, y_max, 200)
    )

    pred_data = pd.DataFrame(np.c_[xx.ravel(), yy.ravel()], columns=X_two.columns)
    Z = dt2.predict(pred_data)
    Z_encoded = le.transform(Z)
    Z = Z_encoded.reshape(xx.shape)

    plt.contourf(xx, yy, Z, alpha=0.4)

    plt.scatter(
        X_two.iloc[:,0],
        X_two.iloc[:,1],
        c=y_encoded,
        edgecolor="k"
    )

    plt.title("Decision Boundary")
    plt.show()